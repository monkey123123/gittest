package com.cn;
/**
 * 测试类
 * MailUtil工具类和MailUtil2工具类都可以实现发送邮件
 * MailUtil2工具类只能发送文本邮件；MailUtil工具类支持发送文本和 带附件的邮件
 * 
 * @version 1.0 2017年12月16日
 * @author  luokun
 * @since JDK1.8
 */
public class Test {
	
	public static void main(String[] args){
		MailUtil2.send();
	}

}
