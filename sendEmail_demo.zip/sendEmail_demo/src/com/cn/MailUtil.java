package com.cn;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

public class MailUtil {
	public static Properties prop = new Properties();
	private static Session session = null ;
	private static Message msg;
	private static Transport transport;
	private static String sender_username =  "cattznwg@163.com";
	private static String sender_password = "Cat2016";
	private static String port = "25";
	private static String host = "smtp.163.com";
	
	public static void init(){
		prop.put("address", sender_username);
		prop.put("password", sender_password);
		prop.put("mail.smtp.port", port);
		prop.put( "mail.smtp.host", host);       
		prop.put("mail.smtp.auth", "true"); 
		prop.put("mail.transport.protocol", "smtp"); 
		session = Session.getInstance(prop);
	}
	
	public static void main(String[] args) throws UnsupportedEncodingException, MessagingException {
		prop.put("address", sender_username);
		prop.put("password", sender_password);
		prop.put("mail.smtp.port", 25);
		prop.put( "mail.smtp.host", "smtp.gdcattsoft.com");       
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.transport.protocol", "smtp");
		session = Session.getInstance(prop);
		
		 // 打开调试，会打印与邮箱服务器回话的内容  
        session.setDebug(true);  
        Message message = new MimeMessage(session);  
        // 如果发送人没有写对，那么会出现 javamail 550 Invalid User  
        // 如果发送人写的和使用的帐号不一致，则会出现 553 Mail from must equal authorized user  
        InternetAddress from = new InternetAddress("lizhizhi@gdcattsoft.com");  
        from.setPersonal(MimeUtility.encodeText("java"));  
        message.setFrom(from);  
        InternetAddress to = new InternetAddress("lizhizhi@gdcattsoft.com");  
        message.setRecipient(Message.RecipientType.TO, to);  
        message.setSubject(MimeUtility.encodeText("1111"));  
        message.setText("22222");  
        message.setSentDate(new Date());  
        Transport transport = session.getTransport("smtp");  
        // 具体你使用邮箱的smtp地址和端口，应该到邮箱里面查看，如果使用了SSL，网易的端口应该是 465/994  
        transport.connect("smtp.gdcattsoft.com", 25, "lizhizhi@gdcattsoft.com", "aaaaaaaaa");  
        transport.sendMessage(message, message.getAllRecipients());  
        transport.close();  
        System.out.println("发送完毕"); 
	}
	
	
	/**
	 * 发送邮件
	 */
	public static Boolean sendMail(String subject, String sendHtml,List<String> receiveUser, List<File> attachment) {
		boolean flag = true;
		try {
			init();
			msg = new MimeMessage(session);
			// 发件人
			InternetAddress from = new InternetAddress(sender_username);
			msg.setFrom(from);

			// 收件人
			InternetAddress[] sendTo = new InternetAddress[receiveUser.size()];  
	        for (int i = 0; i < receiveUser.size(); i++) {  
	            sendTo[i] = new InternetAddress(receiveUser.get(i));  
	        } 
			msg.setRecipients(Message.RecipientType.TO, sendTo);

			// 邮件主题
			msg.setSubject(subject);

			// 向multipart对象中添加邮件的各个部分内容，包括文本内容和附件
			Multipart multipart = new MimeMultipart();

			// 添加邮件正文
			BodyPart contentPart = new MimeBodyPart();
			contentPart.setContent(sendHtml, "text/html;charset=UTF-8");
			multipart.addBodyPart(contentPart);

			// 添加附件的内容
			for (int i = 0; i < attachment.size(); i++) {  
				BodyPart attachmentBodyPart = new MimeBodyPart();
				DataSource source = new FileDataSource(attachment.get(i));
				attachmentBodyPart.setDataHandler(new DataHandler(source));
				// MimeUtility.encodeWord可以避免文件名乱码
				attachmentBodyPart.setFileName(MimeUtility
						.encodeWord(attachment.get(i).getName()));
				multipart.addBodyPart(attachmentBodyPart); 
	        }
			// 将multipart对象放到msg中
			msg.setContent(multipart);
			// 保存邮件
			msg.saveChanges();
			transport = session.getTransport("smtp");
			// smtp验证，就是你用来发邮件的邮箱用户名密码
			transport.connect(host, Integer.parseInt(port), sender_username,
					sender_password);
			// 发送
			transport.sendMessage(msg, msg.getAllRecipients());

		} catch (Exception e) {
			flag = false;
			throw new RuntimeException("邮件发送失败",e);
		} finally {
			if (transport != null) {
				try {
					transport.close();
				} catch (MessagingException e) {
					e.printStackTrace();
				}
			}
		}

		return flag;
	}
}
