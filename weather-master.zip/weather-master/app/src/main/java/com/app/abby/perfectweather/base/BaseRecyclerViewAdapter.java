package com.app.abby.perfectweather.base;

import android.support.v7.widget.RecyclerView;
import android.widget.AdapterView;

/**
 * Created by Abby on 8/14/2017.
 */

public abstract class BaseRecyclerViewAdapter<T extends RecyclerView.ViewHolder> extends RecyclerView.Adapter<T>{



}

