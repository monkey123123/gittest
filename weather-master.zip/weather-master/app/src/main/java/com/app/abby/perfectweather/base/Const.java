package com.app.abby.perfectweather.base;

/**
 * Created by Abby on 8/13/2017.
 */

public class Const {
    public static String API_KEY="cacdb2b118134e81a460df68cadd90b8";

    public static String DB_NAME="weather.db";


}
