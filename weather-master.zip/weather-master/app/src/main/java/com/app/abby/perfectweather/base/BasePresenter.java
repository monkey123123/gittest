package com.app.abby.perfectweather.base;

/**
 * Created by Abby on 8/13/2017.
 */

public interface BasePresenter {

     void onsubscribe(String city);
     void onunsubscribe();
}
