package com.app.abby.perfectweather.model.data;

/**
 * Created by Abby on 8/29/2017.
 */
public class City {

    public String CityName;
    public int ProID;
    public int CitySort;

}