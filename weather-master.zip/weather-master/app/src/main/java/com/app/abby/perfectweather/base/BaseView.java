package com.app.abby.perfectweather.base;

/**
 * Created by Abby on 8/13/2017.
 */

public interface BaseView<T> {

    void setPresenter(T presenter);
}
